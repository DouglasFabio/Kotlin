fun main() {
/*Slide 44: Pesquisa em Vetores
    //Exemplo 1
    var valores = arrayOf(10,20,30,50)
    for(i in valores)
        if(i == 20){
            println("O vetor contém o buscado!")
            break;
        }

    //Exemplo 2
    var valores = arrayOf(10,20,30,50)
    if(20 in valores)
        println("O vetor contém o buscado!")

     Novo Exemplo: Procurando o número 50 utilizando o exemplo 2
*/
    var valores = arrayOf(10,20,30,50)
    if(50 in valores)
        println("O vetor contém o buscado!")
}
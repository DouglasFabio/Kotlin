fun main() {
/*Slide 42: For com in
    var valores = arrayOf(10,20,30,50)
    for(i in valores)
        print("saldo: $i,")



    Novo Exemplo: Criando um vetor de valores impares e imprimindo todos
*/
    var valoresImpares = arrayOf(1,3,5,7,9,11,13,15,17)
    for(i in valoresImpares)
        print("Impar: $i,")
}
fun main(){
/*Slide 34: Concatenação e Interpolação com variáveis
    var a = 1 + 1
    println(a)
    println("result: "+a)
    println("result: $a")
    println("result: ${a}")
    println("result: ${a+1}")

    Novo Exemplo: Somando dois números na variável e subtraindo no último exemplo de result.
*/
    var a = 285 + 15
    println(a)
    println("result: "+a)
    println("result: $a")
    println("result: ${a}")
    println("result: ${a-15}")
}
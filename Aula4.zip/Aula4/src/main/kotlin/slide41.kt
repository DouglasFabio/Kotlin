fun main() {
/*Slide 41: Laços de Repetição
    //Exemplo 1
    var i = 0
    while(i <10){
        print("$i,")
        i++
    }

    //Exemplo 2
    var i = 0
    while(i <10){
        print("${i++},")
    }

    //Exemplo 3
    var i = 0
    do
        print("${++i},")
    while(i < 10)

    Novo Exemplo: Começando a imprimir a partir do número 5
*/
    var i = 0
    while(i < 20){
        print("${i+5},")
        i++
    }
}
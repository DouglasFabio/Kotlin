fun main(){
/*Slide 40: Vetores
    var lista = ArrayList<String>()
    lista.add("RS")
    lista.add("MG")
    lista.add("SP")
    lista.add("RJ")
    println(lista[0])
    lista.sort()
    println(lista[0])
    lista.sortDescending()
    println(lista[0])

    Novo Exemplo: Adicionando hardwares em uma lista, ordenando e imprimindo a nova ordem
*/
    var listaHardware = ArrayList<String>()
    listaHardware.add("Mouse")
    listaHardware.add("Teclado")
    listaHardware.add("Monitor")
    listaHardware.add("Headset")
    listaHardware.sort()
    println(listaHardware[0])
    listaHardware.sortDescending()
    println(listaHardware[0])

}
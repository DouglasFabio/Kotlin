fun main(){
    /*Slide 31: Realizando pesquisas em strings
        val myText = "Hello"
        println(myText)
        println(myText.contains("a"))
        println(myText.contains("b"))
        println(myText.contains("l"))

    Novo Exemplo: Pesquisando todas as vogais na palavra Paralelepipedo.
     */
    val palavra = "Paralelepipedo"
    println(palavra)
    println(palavra.contains("a"))
    println(palavra.contains("e"))
    println(palavra.contains("i"))
    println(palavra.contains("o"))
    println(palavra.contains("u"))
}
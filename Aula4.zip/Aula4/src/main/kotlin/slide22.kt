fun main(){
/*
Exemplo Slide 22: Mostrando o comando de imprimir pulando linha e imprimir sem pular linha.
    println("Hello World!")
    print("Meunome é ")
    print("Kotlin")

Novo exemplo: Imprimindo o nome do curso e da instituição
 */
    println("Pós-Graduação Latu Sensu - Desenvolvimento para Internet e Dispositivos Móveis")
    print("IFSP - ")
    print("Campus Barretos")
}
fun main(){
    /*Slide 39: Vetores

        //Exemplo 1
        var estados = arrayOf("SP","MG","RJ","RS")
        print(estados[0])

        //Exemplo 2
        var lista = ArrayList<String>()
        lista.add("RS")
        lista.add("MG")
        lista.add("SP")
        lista.add("RJ")
        println(lista[0])

        //Exemplo 3
        val valores = arrayOf(10,20,30,50)
        print(valores[0])

        Novo Exemplo: Adicionando hardwares em uma lista e imprimindo o item Monitor.
    */
    var listaHardware = ArrayList<String>()
    listaHardware.add("Mouse")
    listaHardware.add("Teclado")
    listaHardware.add("Monitor")
    listaHardware.add("Headset")
    println(listaHardware[2])

}
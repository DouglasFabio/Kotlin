/* Slide 65
- Criado o pacote "br.com.douglasfabio.util"
- Criado a classe Calculadora
- Adicionado sobrecarga (SLIDE 66)
*/
import br.com.douglasfabio.util.Calculadora

fun main(){
    println(Calculadora().soma(5, 5))
}
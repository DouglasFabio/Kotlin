fun main() {
    /*Slide 47: Funções com retorno
    //Exemplo 1
    print(soma(1,1))

    fun soma(v1: Int, v2: Int): Int{
        return v1 + v2
    }

    //Exemplo 2
    print(soma(1,1))

    fun soma(v1: Int, v2: Int) = v1 + v2

     Novo Exemplo: Somando 10 + 20 e retornando o valor da função soma
*/
    print(soma(10, 20))
}
fun soma(v1: Int, v2: Int): Int {
    return v1 + v2
}

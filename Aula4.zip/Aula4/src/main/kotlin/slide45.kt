fun main() {
/*Slide 45: Ranges
    //Exemplo 1
    for(i in 1 .. 10)
        print("$i,")

    //Exemplo 2
    for(i in 'a' .. 'z')
        print("$i,")

     Novo Exemplo: Percorrendo a metade do alfabeto utilizando o exemplo 2
*/
    for(i in 'a' .. 'm')
        print("$i,")
}
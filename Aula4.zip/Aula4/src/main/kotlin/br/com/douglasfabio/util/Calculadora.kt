package br.com.douglasfabio.util

class Calculadora {
    fun soma(v1: Int, v2: Int) = v1 + v2
    fun subtracao(v1: Int, v2: Int) = v1 - v2
    fun multiplicacao(v1: Int, v2: Int) = v1 * v2
    //fun divisao(v1: Int, v2: Int) = v1 / v2
    fun divisao(v1: Int, v2: Int) = v1 / v2.toFloat()
    fun divisao(v1: Float, v2: Float) = v1 / v2
}